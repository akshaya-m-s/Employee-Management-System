import React from 'react'
import './adnav.css'
// import { Link } from 'react-router-dom'
// import Tablee from './Employee/Table'

function AdminNav() {
  return (
    <>
    <div className="oy">
     <nav className="navbar">
        <div className="navbar-container">
            <div className="logo">EMPLOYEE ATTENDANCE SYSTEM</div>
            <ul className="nav-links">
             {/* <Link to={'/table'}>   <li><a href="#dashboard">Dashboard</a></li></Link> */}
                <li><a href="#dashboard">Dashboard</a></li>
                <li><a href="#attendance">Attendance</a></li>
                <li><a href="#reports">Reports</a></li>
                <li><a href="#settings">Settings</a></li>
            </ul>
            <div className="menu-toggle">&#9776;</div>
        </div>
    </nav>
    
       </div>
    <div className="bi">
    {/* <Tablee/> */}

    </div>
    </>
  )
}

export default AdminNav