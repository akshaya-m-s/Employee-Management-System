import React from 'react'
import './sign.css'
import { Link } from 'react-router-dom'

function SignOut() {
  return (
    <>
    <div className="sg">
      <div className="con">
        <div class="sign-out-card">
            <h1 className='htag'>Are u sure.? Sign Out</h1>
        <Link to={'/'}>    <a href="#" className="sign-in-btn">Sign Out</a></Link>
        </div>
    </div>
    </div>
    </>
  )
}

export default SignOut