import React from 'react'
import './edit.css'

function EditForm() {
  return (
    <><div className="e">
     <div className="cr">
        <h1 className='ee'>EDIT EMPLOYEE FORM</h1>
        <form className="edit-form">
            <div className="form-group">
                <label for="employee-id">Employee ID</label>
                <input type="text" id="employee-id" className="form-control" placeholder='01' required/>
            </div>

            <div className="form-group">
                <label for="name">Name</label>
                <input type="text" id="name" className="form-control" placeholder='Gowtham' required/>
            </div>

            <div className="form-group">
                <label for="department">Department</label>
                <input type="text" id="department" className="form-control" placeholder='web development' required/>
            </div>

            <div className="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" className="form-control" placeholder='gowtham@gmail.com' required/>
            </div>

            <div className="buttonn-group">
                <button type="submit" className="btnn btnn-primary">Save Changes</button>
            </div>
        </form>
    </div>
    </div>  
    </>
  )
}

export default EditForm