import React from 'react'
import './nav.css'
import { Link } from 'react-router-dom'


function Nav() {
  return (
    <>
    <div className="bg">
    <div className="bod">
    <div className="hero">
        <div className="hero-content">
            {/* <h1 className='hhh'>Employee Attendance</h1> */}
            <p className='pa'>One Good Think About Punctuality IS...</p>
            <div className="btnnn-container">

          <Link to={'/ad'}><button className="btnnn btn-primary">Admin Login</button></Link>
          <Link to={'/employe'}><button className="btnnn btn-secondary">Employe Login</button></Link>
               
            </div>
        </div>
        </div>
        </div>
    </div>
    </>
  )
}

export default Nav




































































    {/* <div className="bd">
      <nav className="navbar">

        <div className="logo">Employee Attendance System</div>
        <div className="login-buttons">
            <a href="#" className="login-button">
                User Login
            </a>
            <a href="#" className="login-button admin-login">
                Admin Login
            </a>
        </div>
    </nav> */}
    {/* <img className='bg' src={bio} alt="" /> */}


        {/* <!-- Add your main content here --> */}
        {/* <h1 style="text-align: center; margin-top: 2rem;">Welcome to the Employee Attendance System</h1> */}
    {/* </div> */}
    