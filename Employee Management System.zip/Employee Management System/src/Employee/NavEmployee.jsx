import React from 'react'
import './navemp.css'
import { Link } from 'react-router-dom'

function NavEmployee() {
  return (
    <>

     <div className="cover">
        <div className="overlay"></div>
        <div className="button-container">
         <Link to={'/leave'}>   <a href='leave' className="butto">Leave Form</a></Link>
         <Link to={'/profile'}>   <a href='leave' className="butto">Profile</a></Link>
         <Link to={'/success'}>   <a href='leave' className="butto">Entry Form</a></Link>
         <Link to={'/employe'}>   <a href='leave' className="butto">Sign Out</a></Link>
        </div>
    </div>
   
    </>
  )
}

export default NavEmployee