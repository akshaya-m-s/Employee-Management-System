import React from 'react'
import './table.css'

function Tablee() {
  return (
    <>
    <div className="y">
        <div class="contanr">
        <table class="attendance-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Present</th>
                    <th>Absent</th>
                    <th>Holiday</th>
                    <th>Attendance</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Andrew Ebel</td>
                    <td>4</td>
                    <td>2</td>
                    <td>1</td>
                    <td><button className="manage-btn">Manage</button></td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Anna Fischer</td>
                    <td>4</td>
                    <td>1</td>
                    <td>1</td>
                    <td><button className="manage-btn">Manage</button></td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Bruno Den</td>
                    <td>11</td>
                    <td>2</td>
                    <td>2</td>
                    <td><button className="manage-btn">Manage</button></td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Christine</td>
                    <td>2</td>
                    <td>0</td>
                    <td>0</td>
                    <td><button className="manage-btn">Manage</button></td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Donald Davis</td>
                    <td>7</td>
                    <td>4</td>
                    <td>2</td>
                    <td><button className="manage-btn">Manage</button></td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>John Sosa</td>
                    <td>4</td>
                    <td>6</td>
                    <td>2</td>
                    <td><button className="manage-btn">Manage</button></td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>Katherine Mercado</td>
                    <td>6</td>
                    <td>3</td>
                    <td>2</td>
                    <td><button className="manage-btn">Manage</button></td>
                </tr>
                <tr>
                    <td>8</td>
                    <td>Lewis Villa</td>
                    <td>6</td>
                    <td>3</td>
                    <td>2</td>
                    <td><button className="manage-btn">Manage</button></td>
                </tr>
            </tbody>
        </table>
    </div>
    </div>
    </>
  )
}

export default Tablee