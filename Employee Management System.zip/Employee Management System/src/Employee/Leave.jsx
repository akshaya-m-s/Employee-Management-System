import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'; // Import useNavigate
import './leave.css';

function Leave() {
  // State for form data
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    dep: '',
    from_date: '',
    to_date: '',
    leavetype: '',
  });

  
  const navigate = useNavigate();

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Create the payload object
    const payload = {
      name: formData.name,
      email: formData.email,
      dep: formData.dep,
      from_date: formData.from_date,
      to_date: formData.to_date,
      leavetype: formData.leavetype,
    };

    try {
      // Send a POST request to your backend API endpoint (replace with your backend URL)
      const response = await axios.post('http://localhost/employeemanagebackend/controllers/api/User/post/leave.php', payload);

      // Handle success response (optional)
      console.log('Leave request submitted successfully:', response.data);
      
      // Optionally reset form or show success message
      setFormData({
        name: '',
        email: '',
        dep: '',
        from_date: '',
        to_date: '',
        leavetype: '',
      });

      // Redirect to another page (e.g., a confirmation page or dashboard)
      navigate('/navemp');  // Replace '/leave-success' with the desired route
    } catch (error) {
      // Handle error response
      console.error('Error submitting leave request:', error);
    }
  };

  return (
    <>
      <div className="bdy">
        <div className="conta">
          <h1>Employee Leave Request Form</h1>
          <form className="leaveForm" onSubmit={handleSubmit}>
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="name">Name</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor="department">Department</label>
              <input
                type="text"
                id="dep"
                name="dep"
                value={formData.dep}
                onChange={handleChange}
                required
              />
            </div>
            <div className="form-row">
              <div className="form-group">
              <label htmlFor="leaveStart">Leave Start Date</label>
    <input
      type="date"
      id="from_date"
      name="from_date" 
      value={formData.from_date}
      onChange={handleChange}
      required
                />
              </div>
              <div className="form-group">
              <label htmlFor="leaveEnd">Leave End Date</label>
    <input
      type="date"
      id="to_date"
      name="to_date"
      value={formData.to_date}
      onChange={handleChange}
      required
                />
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="leavetype">Leave Type</label>
              <select
                id="leavetype"
                name="leavetype"
                value={formData.leavetype}
                onChange={handleChange}
                required
              >
                <option value="">Select Leave Type</option>
                <option value="vacation">Vacation</option>
                <option value="sick">Sick Leave</option>
                <option value="personal">Personal Leave</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div className="form-group">
              <button className="buton" type="submit">Submit Leave Request</button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
}

export default Leave;

