
import React from 'react'
import './employee.css'

function Employe() {
  return (
    <>
    <header>
        <h1>Employee Attendance System</h1>
    </header>

    <div class="container">
        <main class="attendance-grid">
            <div class="employee-card">
                <img src="/placeholder.svg?height=100&width=100" alt="John Doe"/>
                <h3>John Doe</h3>
                <p class="status present">Present</p>
                <div class="clock-in-out">
                    <a href="#" class="btn">Clock Out</a>
                </div>
            </div>

            <div class="employee-card">
                <img src="/placeholder.svg?height=100&width=100" alt="Jane Smith"/>
                <h3>Jane Smith</h3>
                <p class="status absent">Absent</p>
                <div class="clock-in-out">
                    <a href="#" class="btn">Clock In</a>
                </div>
            </div>

            <div class="employee-card">
                <img src="/placeholder.svg?height=100&width=100" alt="Bob Johnson"/>
                <h3>Bob Johnson</h3>
                <p class="status present">Present</p>
                <div class="clock-in-out">
                    <a href="#" class="btn">Clock Out</a>
                </div>
            </div>

            <div class="employee-card">
                <img src="/placeholder.svg?height=100&width=100" alt="Alice Williams"/>
                <h3>Alice Williams</h3>
                <p class="status absent">Absent</p>
                <div class="clock-in-out">
                    <a href="#" class="btn">Clock In</a>
                </div>
            </div>

            <div class="employee-card">
                <img src="/placeholder.svg?height=100&width=100" alt="Charlie Brown"/>
                <h3>Charlie Brown</h3>
                <p class="status present">Present</p>
                <div class="clock-in-out">
                    <a href="#" class="btn">Clock Out</a>
                </div>
            </div>

            <div class="employee-card">
                <img src="/placeholder.svg?height=100&width=100" alt="Diana Prince"/>
                <h3>Diana Prince</h3>
                <p class="status absent">Absent</p>
                <div class="clock-in-out">
                    <a href="#" class="btn">Clock In</a>
                </div>
            </div>
        </main>
    </div>
    </>
  )
}

export default Employe