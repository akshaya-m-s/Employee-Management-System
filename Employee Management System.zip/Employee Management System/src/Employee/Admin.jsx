import React, { useState } from 'react';
import axios from 'axios';
import './ad.css';
import { useNavigate } from 'react-router-dom';

function Admin() {
  const [name, setname] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = { name, password };

    try {
      const response = await axios.post('http://localhost/employeemanagebackend/controllers/api/admin/post/adminlogin.php', payload);
      console.log('Login successful:', response.data.message);
      
     
      navigate('/dash'); 
    } catch (error) {
      console.error('Error logging in:', error);
    }
  };

  return (
    <>
      <div className="admin-div">
        <div className="login-container">
          <h1 className="login-title">Admin Login</h1>
          <form className="login-form" onSubmit={handleSubmit}>
            <div className="form-groupp">
              <label className='ll' htmlFor="username">Username</label>
              <input 
                type="text" 
                id="name" 
                name="name" 
                value={name} 
                onChange={(e) => setname(e.target.value)} 
                required 
              />
            </div>
            <div className="form-groupp">
              <label className='ll' htmlFor="password">Password</label>
              <input 
                type="password" 
                id="password" 
                name="password" 
                value={password} 
                onChange={(e) => setPassword(e.target.value)} 
                required 
              />
            </div>
            <button type="submit" className="login-button1">Login</button>
          </form>
        </div>
      </div>
    </>
  );
}

export default Admin;


