import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './EntryForm.css'; // Import the CSS file

function EntryForm() {
  const [name, setName] = useState('');
  const [dep, setDepartment] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();

    const formData = {
      name,
      dep,
      email,
    };

    try {
      const response = await axios.post(
        'http://localhost/employeemanagebackend/controllers/api/User/post/entryform.php',
        formData
      );
      console.log('Server Response:', response.data);

      setName('');
      setDepartment('');
      setEmail('');

      setMessage(response.data.message || 'Data submitted successfully!');

      setTimeout(() => {
        navigate('/navemp');
      }, 1000);
    } catch (error) {
      console.error('Error submitting data:', error);
      setMessage('Failed to submit data. Please try again.');
    }
  };

  return (
    <div className="entry-form-container">
      <h2 className="form-title">Employee Entry Form</h2>

      <form onSubmit={handleSubmit} className="entry-form">
        <div className="form-group">
          <label htmlFor="name">Name:</label>
          <input
            id="name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="dep">Department:</label>
          <input
            id="dep"
            type="text"
            value={dep}
            onChange={(e) => setDepartment(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <button type="submit" className="submit-button">Submit</button>
      </form>

      {message && <div className={`message ${message.includes('success') ? 'success' : 'error'}`}>{message}</div>}
    </div>
  );
}

export default EntryForm;
