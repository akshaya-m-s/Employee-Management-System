import React, { useState, useEffect } from 'react';
import axios from 'axios'; 
import './atten.css';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';

function AttenProfile() {
  const [employeeDetails, setEmployeeDetails] = useState({});
  const [attendanceRecords, setAttendanceRecords] = useState([]);
  const [loading, setLoading] = useState(true); 
  const [error, setError] = useState(''); 

  useEffect(() => {
    const fetchEmployeeData = async () => {
      try {
        const response = await axios.get(
          'http://localhost/employeemanagebackend/controllers/api/admin/get/userdetail.php'
        );
  
        console.log('API Response:', response.data);
  
        const employeeData = response.data[0] || {};
        const { id, name, dep, position, email, phone, leavedate, status } = employeeData;
  
        setEmployeeDetails({
          id,
          name,
          dep,
          position,
          email,
          phone,
        });
  
     
        if (leavedate && status) {
          setAttendanceRecords([
            {
              date: leavedate,
              status: status,
            },
          ]);
        } else {
          setAttendanceRecords([]);
        }
  
        setLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setError('Failed to load data. Please try again later.');
        setLoading(false);
      }
    };
  
    fetchEmployeeData();
  }, []);
  

  if (loading) return <div className="loading">Loading...</div>;
  if (error) return <div className="error">{error}</div>;

  return (
    <div className="yy">
      <div className="contar">
        <h1>Employee Attendance and Profile</h1>

        <section className="profile">
          <div className="profile-image">
            <AccountCircleIcon style={{ fontSize: 100, color: '#007BFF', borderRadius: '100%' }} />
          </div>

          <div className="profile-details">
            {employeeDetails.id ? (
              <>
                <p><strong>Employee ID:</strong> {employeeDetails.id}</p>
                <p><strong>Name:</strong> {employeeDetails.name}</p>
                <p><strong>Department:</strong> {employeeDetails.dep}</p>
                <p><strong>Position:</strong> {employeeDetails.position}</p>
                <p><strong>Email:</strong> {employeeDetails.email}</p>
                <p><strong>Phone:</strong> {employeeDetails.phone}</p>
              </>
            ) : (
              <p>Loading Profile...</p>
            )}
          </div>
        </section>

        <h2>Attendance Record</h2>
        <table className="attendance-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {attendanceRecords.length > 0 ? (
              attendanceRecords.map((record, index) => (
                <tr key={index}>
                  <td data-label="Date">{record.date}</td>
                  <td data-label="Status">{record.status}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="2" style={{ textAlign: 'center' }}>
                  No attendance records available.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default AttenProfile;
