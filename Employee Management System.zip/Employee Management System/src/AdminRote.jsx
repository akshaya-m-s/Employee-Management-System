// import React from 'react'
// import './flex.css'
// import { Route, Routes } from 'react-router-dom'
// import Drawerr from './Drawerr'
// import Dash from './Dash'
// import SignOut from './SignOut'
// import Department from './Department'
// import EmployeeList from './EmployeeList'
// import Web from './Web'
// import AppDev from './AppDev'
// import Soft from './Soft'
// import Tester from './Tester'
// import { Edit } from '@mui/icons-material'
// import EditForm from './EditForm'
// import EntryForm from './Employee/Entry'
// import WebDevelopment from './Tester'
// import SoftwareDevelopment from './Soft'

// function AdminRote() {
//   return (
//     <>
//     <div className="flex">
// <Drawerr/>

//     <Routes>
//         <Route path={'/dash'} element={<Dash/>}/>
//         <Route path={'/signout'} element={<SignOut/>}/>
//         <Route path={'/department'} element={<Department/>}/>
//         <Route path={'//employeelist'} element={<EmployeeList/>}/>
//         <Route path={'/web'} element={<Web/>}/>
//         <Route path={'/app'} element={<AppDev/>}/>
//         <Route path={'/soft'} element={<Soft/>}/>
//         <Route path={'/test'} element={<Tester/>}/>
//         <Route path={'/edit'} element={<EditForm/>}/>
//         <Route path="/success" element={<EntryForm />} />
//         {/* <Route path="/department/web-development" element={<WebDevelopment/>} />
//         <Route path="/department/software-development" element={<SoftwareDevelopment/>} />
//         <Route path="/department/frontend-development" element={<FrontendDevelopment/>} />
//         <Route path="/department/backend-development" element={<BackendDevelopment/>} />
//         */}
//     </Routes>

//     </div>
//     </>
//   )
// }

// export default AdminRote;

import React from 'react';
import './flex.css';
import { Route, Routes } from 'react-router-dom';
import Drawerr from './Drawerr';
import Dash from './Dash';
import SignOut from './SignOut';
import Department from './Department';
import EmployeeList from './EmployeeList';
import Web from './Web';
import AppDev from './AppDev';
import Soft from './Soft';
import Tester from './Tester';
import { Edit } from '@mui/icons-material';
import EditForm from './EditForm';
import EntryForm from './Employee/Entry';
import WebDevelopment from './Tester';
import SoftwareDevelopment from './Soft';
// import DepartmentDetails from './DepartmentDetails'; // Import the details component

function AdminRote() {
  return (
    <>
      <div className="flex">
        <Drawerr />

        <Routes>
          <Route path={'/dash'} element={<Dash />} />
          <Route path={'/signout'} element={<SignOut />} />
          <Route path={'/department'} element={<Department />} />
          <Route path={'/employeelist'} element={<EmployeeList />} />
          <Route path={'/web'} element={<Web />} />
          <Route path={'/app'} element={<AppDev />} />
          <Route path={'/soft'} element={<Soft />} />
          <Route path={'/test'} element={<Tester />} />
          <Route path={'/edit'} element={<EditForm />} />
          <Route path="/success" element={<EntryForm />} />
          <Route path="/department/:depname" element={<WebDevelopment />} />


         
        </Routes>
      </div>
    </>
  );
}

export default AdminRote;
