
// import React from 'react'
// import './draw.css'
// import adm from './assets/admin.jpeg'
// import { Link } from 'react-router-dom'

// function Drawerr() {
//   return (

//     <>
//     <div className="yd">
// <div className="sidebar">
//     <img src={adm} alt="Admin"/>
//     <h3>Admin</h3>
//     <ul>
//     <Link to={'/dash'}>  <li>Dashboard</li></Link>
//     <Link to={'/department'}>  <li>Department</li></Link>
//     <Link to={'/employeelist'}>  <li>Employee</li></Link>
//    <Link to={'/signout'}><li>Sign Out</li></Link>
//     </ul>
//   </div>

 
//   </div>
//     </>
//   )
// }

// export default Drawerr

import React from 'react';
import './draw.css';
import adm from './assets/admin.jpeg';
import { Link, useLocation } from 'react-router-dom';

function Drawerr() {
  const location = useLocation();

  // Add conditional logic to hide the drawer for the EntryForm path
  const isEntryForm = location.pathname === '/success';

  return (
    <>
      <div className={`yd ${isEntryForm ? 'hide-drawer' : ''}`}>
        <div className="sidebar">
          <img src={adm} alt="Admin" />
          <h3>Admin</h3>
          <ul>
            <Link to={'/dash'}> <li>Dashboard</li></Link>
            <Link to={'/department'}> <li>Leave Details</li></Link>
            <Link to={'/employeelist'}> <li>Employee List</li></Link>
            <Link to={'/signout'}><li>Sign Out</li></Link>
          </ul>
        </div>
      </div>
    </>
  );
}

export default Drawerr;


