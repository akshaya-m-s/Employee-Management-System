import { Route, Routes, useLocation } from "react-router-dom"
import Admin from "./Employee/Admin"
import Nav from "./Employee/Nav"
import EmployeLogin from "./Employee/Employelogin"
import AdminRote from "./AdminRote"
import AttenProfile from "./Employee/AttenProfile"
import NavEmployee from "./Employee/NavEmployee"
import Leave from "./Employee/Leave"
import EntryForm from "./Employee/Entry"
import { Component } from "react"
import SoftwareDevelopment from "./Soft"




  function App() {
    const location = useLocation()
    console.log(location.pathname);
    const route = [
      {
        path:'/',
        Component:Nav
      },
      {
        path:'/ad',
        Component:Admin
      },
      {
        path:'/employe',
        Component:EmployeLogin
      },
      {
        path:'/profile',
        Component:AttenProfile
      },
      {
        path:'/atten',
        Component:AttenProfile
      },
      {
        path:'/navemp',
        Component:NavEmployee
      },
      {
        path:'/leave',
        Component:Leave
      },
      { path:'department',
        Component:'WebDevelopment'
      },
      { path:'/department/software-development',
        Component:' SoftwareDevelopment'
      },
      { path:'/department/frontend-development',
        Component:'Frontenddevelopment'
      },
      { path:'/department/backend-development',
        Component:'BackendDevelopment'
      }
     
      
    
    ]
  
    const routePaths = route.map((r) => r.path);
    console.log(!routePaths.includes(location.pathname));

  return (
    <>
<Routes>

{
  route.map((data,index)=>(
    <Route key={index} path={data.path} element={<data.Component/>}/>
  ))
}

</Routes>


{routePaths.includes(location.pathname) ? null : <AdminRote/>}
    

    </>
  )
}

export default App
