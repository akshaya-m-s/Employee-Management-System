import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './employeelist.css';

function EmployeeList() {
  const [employees, setEmployees] = useState([]);
  const [editingEmployee, setEditingEmployee] = useState(null);
  const [message, setMessage] = useState(''); 


  useEffect(() => {
    axios.get('http://localhost/employeemanagebackend/controllers/api/admin/get/entryform.php')
      .then(response => {
        setEmployees(response.data);
      })
      .catch(error => {
        console.error('Error fetching employee data:', error);
      });
  }, []);

 
  const handleInputChange = (e, field) => {
    setEditingEmployee({
      ...editingEmployee,
      [field]: e.target.value,
    });
  };

 
  const handleEdit = (employee) => {
    setEditingEmployee(employee);
  };

  
  const handleSave = () => {
    axios.post('http://localhost/employeemanagebackend/controllers/api/admin/put/entryform.php', {
      id: editingEmployee.id,
      name: editingEmployee.name,
      dep: editingEmployee.dep,
      email: editingEmployee.email,
    })
      .then(response => {
        setEmployees((prevEmployees) =>
          prevEmployees.map((emp) =>
            emp.id === editingEmployee.id ? editingEmployee : emp
          )
        );
        setEditingEmployee(null); 
        setMessage('Employee updated successfully!');
        setTimeout(() => setMessage(''), 3000); 
      })
      .catch(error => {
        console.error('Error updating employee:', error);
        setMessage('Failed to update employee. Please try again.');
        setTimeout(() => setMessage(''), 3000);
      });
  };

  
  const handleDelete = (id) => {
    axios
      .delete(`http://localhost/employeemanagebackend/controllers/api/admin/delete/entryform.php`, {
        data: { id }, 
      })
      .then((response) => {
        console.log('Delete response:', response.data); 
        setEmployees((prevEmployees) =>
          prevEmployees.filter((employee) => employee.id !== id)
        );
        setMessage('Employee deleted successfully!');
        setTimeout(() => setMessage(''), 3000);
      })
      .catch((error) => {
        console.error('Error deleting employee:', error.response?.data || error.message);
        setMessage('Failed to delete employee. Please try again.');
        setTimeout(() => setMessage(''), 3000);
      });
  };
  
  


  return (
    <div className="em">
      <div className="ctr">
        <h1 className='el'>EMPLOYEE LIST</h1>

        {/* Message Display */}
        {message && <div className="message">{message}</div>}

        <table className="employee-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Department</th>
              <th>Email</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {employees.map((employee) => (
              <tr key={employee.id}>
                {editingEmployee?.id === employee.id ? (
                  <>
                    <td data-label="ID">{employee.id}</td>
                    <td data-label="Name">
                      <input
                        type="text"
                        value={editingEmployee.name}
                        onChange={(e) => handleInputChange(e, 'name')}
                      />
                    </td>
                    <td data-label="Department">
                      <input
                        type="text"
                        value={editingEmployee.dep}
                        onChange={(e) => handleInputChange(e, 'dep')}
                      />
                    </td>
                    <td data-label="Email">
                      <input
                        type="email"
                        value={editingEmployee.email}
                        onChange={(e) => handleInputChange(e, 'email')}
                      />
                    </td>
                    <td data-label="Actions">
                      <button onClick={handleSave} className="bn">Save</button>
                      <button onClick={() => setEditingEmployee(null)} className="bn">Cancel</button>
                    </td>
                  </>
                ) : (
                  <>
                    <td data-label="ID">{employee.id}</td>
                    <td data-label="Name">{employee.name}</td>
                    <td data-label="Department">{employee.dep}</td>
                    <td data-label="Email">{employee.email}</td>
                    <td data-label="Actions">
                      <button
                        onClick={() => handleEdit(employee)}
                        className="bn"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(employee.id)}
                        className="bn delete"
                      >
                        Delete
                      </button>
                    </td>
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default EmployeeList;


