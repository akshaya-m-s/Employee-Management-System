import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './dash.css';

function Dash() {
  // State variables to store fetched data
  const [employeeCount, setEmployeeCount] = useState(0);
  const [departmentCount, setDepartmentCount] = useState(0);
  const [leaveCount, setLeaveCount] = useState(0);

  // Function to fetch data from the API
  const fetchDashboardData = async () => {
    try {
      
      const employeeResponse = await axios.get('http://localhost/employeemanagebackend/controllers/api/admin/get/entryform.php'); 
      const departmentResponse = await axios.get('http://localhost/employeemanagebackend/controllers/api/admin/get/entryform.php'); 
      const leaveResponse = await axios.get('http://localhost/employeemanagebackend/controllers/api/admin/get/leave.php'); 

   
      setEmployeeCount(employeeResponse.data.length);
      setDepartmentCount(departmentResponse.data.length);
      setLeaveCount(leaveResponse.data.length);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    }
  };

 
  useEffect(() => {
    fetchDashboardData();
  }, []);

  return (
    <>
      <div className="main-content">
        <div className="dashboard">
          <div className="stats-grid">
            <div className="stat-card">
              <h3>Total Regd Employee</h3>
              <h2>{employeeCount}</h2>
            </div>
            <div className="stat-card">
              <h3>Listed Departments</h3>
              <h2>{departmentCount}</h2>
            </div>
            <div className="stat-card">
              <h3>Total Leaves</h3>
              <h2>{leaveCount}</h2>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Dash;
