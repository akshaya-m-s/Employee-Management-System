import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './depart.css';
import { Link } from 'react-router-dom';

function Department() {
  const [leaveData, setLeaveData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchLeaveData = async () => {
      try {
        const response = await axios.get(
          'http://localhost/employeemanagebackend/controllers/api/admin/get/leave.php'
        );
        console.log('API Response:', response.data);

        // Assuming response.data is the array of leave records
        setLeaveData(response.data || []);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching leave data:', err);
        setError('Failed to fetch leave data. Please try again later.');
        setLoading(false);
      }
    };

    fetchLeaveData();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div className="d">
      <div className="co">
        <h1 className="dp">LEAVE DETAILS</h1>
        <div className="card-grid">
          {Array.isArray(leaveData) &&
            leaveData.map((leave, index) => (
              <div className="card" key={index}>
                <div className="card-header">
                  <strong>Name:</strong> {leave.name}
                </div>
                <div className="card-body">
                  <p>
                    <strong>Email:</strong> {leave.email}
                  </p>
                  <p>
                    <strong>Department:</strong> {leave.dep}
                  </p>
                  <p>
                    <strong>Leave Type:</strong> {leave.leavetype}
                  </p>
                  <p>
                    <strong>From Date:</strong> {leave.from_date}
                  </p>
                  <p>
                    <strong>To Date:</strong> {leave.to_date}
                  </p>
                </div>
               
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}

export default Department;
