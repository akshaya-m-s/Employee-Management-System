import React from 'react';
import './employeelist.css';

function BackendDevelopment() {
  return (
    <>
      <div className="em">
        <div className="ctr">
          <h1 className="el">APP DEVELOPMENT</h1>
          <table className="employee-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Department</th>
                <th>Email</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td data-label="ID">001</td>
                <td data-label="Name">John Doe</td>
                <td data-label="Department">APP Development</td>
                <td data-label="Email">john.doe@example.com</td>
              </tr>
              {/* Repeat rows as needed */}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

export default BackendDevelopment;
