<?php
include_once '../../../../config/database.php';

class Post
{
    public $conn;
    public $response;

    function __construct()
    {
        $db = new Database();
        $this->conn = $db->connect();
    } 
    public function adminlogin($name,$password)
    {
        $insert = "INSERT INTO admin(name, password) VALUES ( ?, ?)";
        $stmt = mysqli_prepare($this->conn, $insert);
    
        if (!$stmt) {
            return ["message" => "Query preparation error: " . mysqli_error($this->conn)];
        }
    
        mysqli_stmt_bind_param($stmt, "ss", $name,$password);
        $result = mysqli_stmt_execute($stmt);
    
        if ($result) {
            return ["message" => "Plan Added successful"];
        } else {
            return ["message" => "Plan Added failed: " . mysqli_error($this->conn)];
        }
    }
    public function userlogin($name,$password)
    {
        $insert = "INSERT INTO user(name, password) VALUES ( ?, ?)";
        $stmt = mysqli_prepare($this->conn, $insert);
    
        if (!$stmt) {
            return ["message" => "Query preparation error: " . mysqli_error($this->conn)];
        }
    
        mysqli_stmt_bind_param($stmt, "ss", $name,$password);
        $result = mysqli_stmt_execute($stmt);
    
        if ($result) {
            return ["message" => "Plan Added successful"];
        } else {
            return ["message" => "Plan Added failed: " . mysqli_error($this->conn)];
        }
    }
    public function leaveform($name, $email, $dep, $from_date, $to_date, $leavetype)
    {
        // Use backticks for the table name if it is a reserved word
        $insert = "INSERT INTO `leave` (name, email, dep, from_date, to_date, leavetype) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($this->conn, $insert);
    
        if (!$stmt) {
            return ["message" => "Query preparation error: " . mysqli_error($this->conn)];
        }
    
        // Bind parameters
        mysqli_stmt_bind_param($stmt, "ssssss", $name, $email, $dep, $from_date, $to_date, $leavetype);
        $result = mysqli_stmt_execute($stmt);
    
        if ($result) {
            return ["message" => "Plan Added successfully"];
        } else {
            return ["message" => "Plan Add failed: " . mysqli_error($this->conn)];
        }
    }
    
    public function userdetails($id, $name, $dep, $position, $email, $phone, $leavedate, $status) {
        $insert = "INSERT INTO userdetails (id, name, dep, position, email, phone, leavedate, status) 
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($this->conn, $insert);
    
        if (!$stmt) {
            return ["message" => "Query preparation error: " . mysqli_error($this->conn)];
        }
    
        mysqli_stmt_bind_param($stmt, "isssssss", $id, $name, $dep, $position, $email, $phone, $leavedate, $status);
        $result = mysqli_stmt_execute($stmt);
    
        if ($result) {
            return ["message" => "User added successfully"];
        } else {
            return ["message" => "Insertion failed: " . mysqli_error($this->conn)];
        }
    }
    


public function department($depname,$employees, $manager,$tl, $branch)
{
    $insert = "INSERT INTO webdevelopment (depname,employees, manager, tl, branch) VALUES (?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($this->conn, $insert);

    if (!$stmt) {
        return ["message" => "Query preparation error: " . mysqli_error($this->conn)];
    }

    // Correcting type specifiers based on expected data types
    mysqli_stmt_bind_param($stmt, "sssss", $depname,$employees, $manager, $tl, $branch);
    $result = mysqli_stmt_execute($stmt);

    if ($result) {
        return ["message" => "Plan Added successfully"];
    } else {
        return ["message" => "Plan Added failed: " . mysqli_error($this->conn)];
    }
}

public function entryform($name,$dep, $email)
{
    $insert = "INSERT INTO entryform (name,dep,email) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($this->conn, $insert);

    if (!$stmt) {
        return ["message" => "Query preparation error: " . mysqli_error($this->conn)];
    }

    // Correcting type specifiers based on expected data types
    mysqli_stmt_bind_param($stmt, "sss", $name,$dep, $email);
    $result = mysqli_stmt_execute($stmt);

    if ($result) {
        return ["message" => "Plan Added successfully"];
    } else {
        return ["message" => "Plan Added failed: " . mysqli_error($this->conn)];
    }
}



























 





}
?> 
