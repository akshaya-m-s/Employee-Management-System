<?php
include_once '../../../../config/database.php';

class Get
{ 
    public $conn;

    function __construct()
    {
        $db = new Database();
        $this->conn = $db->connect();
    }

    // Function to handle errors and send response
    private function handleResponse($statusCode, $message) 
    {
        http_response_code($statusCode);
        echo json_encode(['error' => $message]);
        exit();
    }

    

   
    //Module:Admin
    //SubModule:Achievement->View
    public function userdetails() 
    {
        
        $query = "SELECT * FROM userdetails ";
        
     
        $stmt = mysqli_prepare($this->conn, $query);
        
        if (!$stmt) {
            $this->handleResponse(500, 'Failed to prepare statement');
            return;
        }
        mysqli_stmt_execute($stmt);
        
        if (mysqli_stmt_errno($stmt)) {
            $this->handleResponse(500, 'Internal server error');
            return;
        }
        
        $result = mysqli_stmt_get_result($stmt);
    
        // Process the result
        if (mysqli_num_rows($result) > 0) {
            $achievementContent = mysqli_fetch_all($result, MYSQLI_ASSOC);
            mysqli_free_result($result);
            mysqli_stmt_close($stmt);
            return $achievementContent;
        } else {
            mysqli_stmt_close($stmt);
            return ['error' => 'No Details Found'];
        }
    }






    public function deps($webDevelopment) 
{        
    // Query to select data for a specific department
    $query = "SELECT id, name, dep, email
              FROM entryform 
              WHERE dep = we?";
              
    $stmt = mysqli_prepare($this->conn, $query);
    
    if ($stmt === false) {
        // If the statement preparation fails
        die('MySQL prepare failed: ' . mysqli_error($this->conn));
    }

    // Bind the department name parameter to the query
    mysqli_stmt_bind_param($stmt, 's', $webDevelopment);
    
    if (!mysqli_stmt_execute($stmt)) {
        // Check if the query execution fails
        die('Execute failed: ' . mysqli_stmt_error($stmt));
    }

    $result = mysqli_stmt_get_result($stmt);
    
    if ($result === false) {
        // Check if fetching the result fails
        die('Get result failed: ' . mysqli_error($this->conn));
    }

    if (mysqli_num_rows($result) > 0) {
        // Fetch all rows and return them
        $PlanContent = mysqli_fetch_all($result, MYSQLI_ASSOC);
        mysqli_free_result($result);
        mysqli_stmt_close($stmt);
        return $PlanContent;
    } else {
        // No rows found, return an appropriate error message
        mysqli_stmt_close($stmt);
        return ['error' => 'No employees found in this department'];
    }
}

    



    public function leave() 
{
    // SQL query to retrieve all rows from the 'leave' table
    $query = "SELECT * FROM `leave`";  // Added backticks around 'leave' to prevent issues with reserved keywords

    // Prepare the SQL statement
    $stmt = mysqli_prepare($this->conn, $query);
    
    // Check if the statement preparation failed
    if (!$stmt) {
        // Log the error for debugging purposes
        error_log('MySQL error: ' . mysqli_error($this->conn));
        
        // Handle the response if the query preparation fails
        $this->handleResponse(500, 'Failed to prepare statement');
        return;
    }
    
    // Execute the prepared statement
    mysqli_stmt_execute($stmt);

    // Check for any errors during execution
    if (mysqli_stmt_errno($stmt)) {
        // Log the error for debugging purposes
        error_log('MySQL execution error: ' . mysqli_stmt_error($stmt));
        
        // Handle the response if execution fails
        $this->handleResponse(500, 'Internal server error');
        return;
    }

    // Get the result of the executed statement
    $result = mysqli_stmt_get_result($stmt);

    // Check if the result contains rows
    if (mysqli_num_rows($result) > 0) {
        // Fetch all rows as an associative array
        $achievementContent = mysqli_fetch_all($result, MYSQLI_ASSOC);
        
        // Free the result memory
        mysqli_free_result($result);

        // Close the statement
        mysqli_stmt_close($stmt);

        // Return the result data
        return $achievementContent;
    } else {
        // No records found, close statement and return an error message
        mysqli_stmt_close($stmt);
        return ['error' => 'No Details Found'];
    }
}




    public function department() 
    {
        
        $query = "SELECT * FROM webdevelopment";
        
     
        $stmt = mysqli_prepare($this->conn, $query);
        
        if (!$stmt) {
            $this->handleResponse(500, 'Failed to prepare statement');
            return;
        }
        
       
       
        
     
        mysqli_stmt_execute($stmt);
        
        if (mysqli_stmt_errno($stmt)) {
            $this->handleResponse(500, 'Internal server error');
            return;
        }
    
        
        $result = mysqli_stmt_get_result($stmt);
    
        // Process the result
        if (mysqli_num_rows($result) > 0) {
            $achievementContent = mysqli_fetch_all($result, MYSQLI_ASSOC);
            mysqli_free_result($result);
            mysqli_stmt_close($stmt);
            return $achievementContent;
        } else {
            mysqli_stmt_close($stmt);
            return ['error' => 'No Details Found'];
        }
    }
    public function entryform() 
    {
        
        $query = "SELECT * FROM entryform";
        
     
        $stmt = mysqli_prepare($this->conn, $query);
        
        if (!$stmt) {
            $this->handleResponse(500, 'Failed to prepare statement');
            return;
        }
        
       
       
        
     
        mysqli_stmt_execute($stmt);
        
        if (mysqli_stmt_errno($stmt)) {
            $this->handleResponse(500, 'Internal server error');
            return;
        }
    
        
        $result = mysqli_stmt_get_result($stmt);
    
        // Process the result
        if (mysqli_num_rows($result) > 0) {
            $achievementContent = mysqli_fetch_all($result, MYSQLI_ASSOC);
            mysqli_free_result($result);
            mysqli_stmt_close($stmt);
            return $achievementContent;
        } else {
            mysqli_stmt_close($stmt);
            return ['error' => 'No Details Found'];
        }
    }

  

    public function fourimage() 
    {
        
        $query = "SELECT * FROM fourimage";
        
     
        $stmt = mysqli_prepare($this->conn, $query);
        
        if (!$stmt) {
            $this->handleResponse(500, 'Failed to prepare statement');
            return;
        }
        
       
        // mysqli_stmt_bind_param($stmt, 'i', $id);
        
     
        mysqli_stmt_execute($stmt);
        
        if (mysqli_stmt_errno($stmt)) {
            $this->handleResponse(500, 'Internal server error');
            return;
        }
    
        
        $result = mysqli_stmt_get_result($stmt);
    
        // Process the result
        if (mysqli_num_rows($result) > 0) {
            $achievementContent = mysqli_fetch_all($result, MYSQLI_ASSOC);
            mysqli_free_result($result);
            mysqli_stmt_close($stmt);
            return $achievementContent;
        } else {
            mysqli_stmt_close($stmt);
            return ['error' => 'No Details Found'];

  


   












}}}
    
?>

